# Flutter Simple Calculator app
Simple Calculator app using Flutter

## Preview
![git](https://user-images.githubusercontent.com/91388754/169571040-33d3597e-83d8-4737-925c-e311dffd9373.gif)
## Links
* [My Socials](https://znap.link/CodeWithFlexz)
* [Youtube channel](https://www.youtube.com/channel/UCLVrYXt3SL9rT-IcDmgU9Wg)
* [Instagram](https://instagram.com/codewithflexz)
